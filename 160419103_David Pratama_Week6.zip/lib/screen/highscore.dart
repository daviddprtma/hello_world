import 'package:flutter/material.dart';
import 'package:hello_world/main.dart';
import 'package:hello_world/screen/quiz.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HighScore extends StatelessWidget {
  int _top_point = 0;
  String active_user = '';
  Future<String> checkUser() async {
    final prefs = await SharedPreferences.getInstance();
    String user_id = prefs.getString("user_id") ?? '';
    return user_id;
  }

  Future<int> topPoint() async {
    final prefs = await SharedPreferences.getInstance();
    int _point = prefs.getInt("_point") ?? 0;
    return _point;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        // appBar: AppBar(title: Text('High Score')),
        // body: checkUser(),
        );
  }
}
